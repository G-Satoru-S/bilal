import { apiClient } from './client';
import { API_CONFIG } from '../../config/api';
import { LoginCredentials, RegisterData, User } from '../../types';

export const authApi = {
  login: async (credentials: LoginCredentials) => {
    const { data } = await apiClient.post<{ token: string; user: User }>(
      API_CONFIG.ENDPOINTS.AUTH.LOGIN,
      credentials
    );
    return data;
  },
  
  register: async (userData: RegisterData) => {
    const { data } = await apiClient.post<{ token: string; user: User }>(
      API_CONFIG.ENDPOINTS.AUTH.REGISTER,
      userData
    );
    return data;
  }
};