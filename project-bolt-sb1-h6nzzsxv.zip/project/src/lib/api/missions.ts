import { apiClient } from './client';
import { API_CONFIG } from '../../config/api';
import { Mission } from '../../types';

export const missionsApi = {
  getAll: async () => {
    const { data } = await apiClient.get<Mission[]>(API_CONFIG.ENDPOINTS.MISSIONS.LIST);
    return data;
  },

  getById: async (id: number) => {
    const { data } = await apiClient.get<Mission>(API_CONFIG.ENDPOINTS.MISSIONS.DETAIL(id));
    return data;
  },

  create: async (missionData: Omit<Mission, 'id' | 'createdAt' | 'company'>) => {
    const { data } = await apiClient.post<Mission>(API_CONFIG.ENDPOINTS.MISSIONS.CREATE, missionData);
    return data;
  }
};