import { apiClient } from './client';
import { User } from '../../types';

export const usersApi = {
  getAll: async () => {
    const { data } = await apiClient.get<User[]>('/users');
    return data;
  },
};