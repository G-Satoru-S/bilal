export const API_CONFIG = {
  BASE_URL: 'http://127.0.0.1:8000',
  ENDPOINTS: {
    AUTH: {
      LOGIN: '/api/login',
      REGISTER: '/api/register',
    },
    MISSIONS: {
      LIST: '/api/missions',
      DETAIL: (id: number) => `/api/missions/${id}`,
      CREATE: '/api/missions',
    },
    USERS: {
      LIST: '/api/users',
      DETAIL: (id: number) => `/api/users/${id}`,
    }
  }
} as const;