import { create } from 'zustand';
import { api } from '../lib/axios';
import { LoginCredentials, RegisterData, User } from '../types';

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  login: (credentials: LoginCredentials) => Promise<void>;
  register: (data: RegisterData) => Promise<void>;
  logout: () => void;
}

export const useAuth = create<AuthState>((set) => ({
  user: null,
  isAuthenticated: false,
  login: async (credentials) => {
    const { data } = await api.post('/login', credentials);
    localStorage.setItem('token', data.token);
    set({ user: data.user, isAuthenticated: true });
  },
  register: async (data) => {
    const response = await api.post('/register', data);
    localStorage.setItem('token', response.data.token);
    set({ user: response.data.user, isAuthenticated: true });
  },
  logout: () => {
    localStorage.removeItem('token');
    set({ user: null, isAuthenticated: false });
  },
}));