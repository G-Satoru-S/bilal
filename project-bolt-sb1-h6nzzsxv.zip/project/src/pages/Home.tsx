import { BriefcaseIcon, UsersIcon } from 'lucide-react';
import { Link } from 'react-router-dom';

export function Home() {
  return (
    <div className="max-w-6xl mx-auto">
      <section className="text-center py-16 px-4">
        <h1 className="text-5xl font-bold mb-6">Trouvez les meilleurs talents freelance</h1>
        <p className="text-xl text-gray-600 mb-8">Connectez-vous avec des professionnels qualifiés pour vos projets</p>
        <div className="flex gap-4 justify-center">
          <Link
            to="/register"
            className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition"
          >
            Commencer
          </Link>
          <Link
            to="/missions"
            className="bg-white text-blue-600 px-6 py-3 rounded-lg border border-blue-600 hover:bg-blue-50 transition"
          >
            Voir les missions
          </Link>
        </div>
      </section>

      <section className="grid md:grid-cols-2 gap-8 py-12 px-4">
        <div className="bg-white p-8 rounded-xl shadow-sm border border-gray-100">
          <BriefcaseIcon className="w-12 h-12 text-blue-600 mb-4" />
          <h2 className="text-2xl font-bold mb-4">Pour les entreprises</h2>
          <p className="text-gray-600 mb-4">
            Publiez vos missions et trouvez les meilleurs freelances pour vos projets.
          </p>
          <Link to="/register?role=entreprise" className="text-blue-600 hover:underline">
            Créer un compte entreprise →
          </Link>
        </div>

        <div className="bg-white p-8 rounded-xl shadow-sm border border-gray-100">
          <UsersIcon className="w-12 h-12 text-blue-600 mb-4" />
          <h2 className="text-2xl font-bold mb-4">Pour les freelances</h2>
          <p className="text-gray-600 mb-4">
            Trouvez des missions intéressantes et développez votre activité freelance.
          </p>
          <Link to="/register?role=freelance" className="text-blue-600 hover:underline">
            Créer un compte freelance →
          </Link>
        </div>
      </section>
    </div>
  );
}