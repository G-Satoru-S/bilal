import { useQuery } from '@tanstack/react-query';
import { useParams } from 'react-router-dom';
import { api } from '../lib/axios';
import { Mission } from '../types';
import { MissionHeader } from '../components/missions/MissionHeader';
import { MissionContent } from '../components/missions/MissionContent';
import { MissionActions } from '../components/missions/MissionActions';

export function MissionDetail() {
  const { id } = useParams();
  const { data: mission, isLoading } = useQuery({
    queryKey: ['mission', id],
    queryFn: async () => {
      const { data } = await api.get<Mission>(`/missions/${id}`);
      return data;
    },
  });

  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600" />
      </div>
    );
  }

  if (!mission) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold text-gray-900">Mission non trouvée</h2>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4">
      <MissionHeader mission={mission} />
      <MissionContent mission={mission} />
      <MissionActions mission={mission} />
    </div>
  );
}