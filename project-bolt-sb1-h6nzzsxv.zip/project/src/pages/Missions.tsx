import { useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { api } from '../lib/axios';
import { Mission } from '../types';
import { MissionCard } from '../components/missions/MissionCard';
import { MissionFilters } from '../components/missions/MissionFilters';
import { Button } from '../components/ui/Button'; // Ajout de l'import manquant

export function Missions() {
  const { data: missions, isLoading } = useQuery({
    queryKey: ['missions'],
    queryFn: async () => {
      const { data } = await api.get<Mission[]>('/missions');
      return data;
    },
  });

  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600" />
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">Missions disponibles</h1>
        <Link to="/missions/new">
          <Button>Publier une mission</Button>
        </Link>
      </div>

      <div className="grid grid-cols-12 gap-8">
        <aside className="col-span-3">
          <MissionFilters />
        </aside>

        <div className="col-span-9">
          <div className="grid gap-6">
            {missions?.map((mission) => (
              <MissionCard key={mission.id} mission={mission} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}