import { useQuery } from '@tanstack/react-query';
import { api } from '../lib/axios';
import { User } from '../types';
import { UserCard } from '../components/users/UserCard';
import { UserFilters } from '../components/users/UserFilters';

export function Users() {
  const { data: users, isLoading } = useQuery({
    queryKey: ['users'],
    queryFn: async () => {
      const { data } = await api.get<User[]>('/users');
      return data;
    },
  });

  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600" />
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">Freelances</h1>
      </div>

      <div className="grid grid-cols-12 gap-8">
        <aside className="col-span-3">
          <UserFilters />
        </aside>

        <div className="col-span-9">
          <div className="grid gap-6">
            {users?.map((user) => (
              <UserCard key={user.id} user={user} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}