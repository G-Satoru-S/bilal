export type Role = 'freelance' | 'entreprise';

export interface User {
  id: number;
  email: string;
  role: Role;
  createdAt: string;
}

export interface Mission {
  id: number;
  title: string;
  description: string;
  type: string;
  requiredExperience: string;
  createdAt: string;
  company: User;
}

export interface LoginCredentials {
  email: string;
  password: string;
}

export interface RegisterData extends LoginCredentials {
  role: Role;
}