import { useState } from 'react';
import { Button } from '../ui/Button';

export function MissionFilters() {
  const [filters, setFilters] = useState({
    type: '',
    experience: '',
  });

  return (
    <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100">
      <h2 className="font-semibold mb-4">Filtres</h2>
      
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Type de mission
          </label>
          <select
            value={filters.type}
            onChange={(e) => setFilters(prev => ({ ...prev, type: e.target.value }))}
            className="w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm"
          >
            <option value="">Tous</option>
            <option value="development">Développement</option>
            <option value="design">Design</option>
            <option value="marketing">Marketing</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Expérience requise
          </label>
          <select
            value={filters.experience}
            onChange={(e) => setFilters(prev => ({ ...prev, experience: e.target.value }))}
            className="w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm"
          >
            <option value="">Tous niveaux</option>
            <option value="junior">Junior</option>
            <option value="intermediate">Intermédiaire</option>
            <option value="senior">Senior</option>
          </select>
        </div>

        <Button
          variant="outline"
          className="w-full"
          onClick={() => setFilters({ type: '', experience: '' })}
        >
          Réinitialiser les filtres
        </Button>
      </div>
    </div>
  );
}