import { GraduationCapIcon } from 'lucide-react';
import { Mission } from '../../types';

interface MissionContentProps {
  mission: Mission;
}

export function MissionContent({ mission }: MissionContentProps) {
  return (
    <div className="bg-white p-8 rounded-lg shadow-sm border border-gray-100 mb-8">
      <div className="prose max-w-none">
        <h2 className="text-xl font-semibold mb-4">Description de la mission</h2>
        <p className="text-gray-600 whitespace-pre-line">{mission.description}</p>
        
        <div className="mt-8">
          <h3 className="text-lg font-semibold mb-2">Expérience requise</h3>
          <div className="flex items-center gap-2 text-gray-600">
            <GraduationCapIcon className="w-5 h-5" />
            <span>{mission.requiredExperience}</span>
          </div>
        </div>
      </div>
    </div>
  );
}