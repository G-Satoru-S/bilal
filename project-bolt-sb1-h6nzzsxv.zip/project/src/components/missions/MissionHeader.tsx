import { CalendarIcon, BriefcaseIcon, BuildingIcon } from 'lucide-react';
import { Mission } from '../../types';
import { formatDate } from '../../lib/date';

interface MissionHeaderProps {
  mission: Mission;
}

export function MissionHeader({ mission }: MissionHeaderProps) {
  return (
    <div className="bg-white p-8 rounded-lg shadow-sm border border-gray-100 mb-8">
      <h1 className="text-3xl font-bold mb-4">{mission.title}</h1>
      
      <div className="flex items-center gap-6 text-sm text-gray-500">
        <div className="flex items-center gap-2">
          <BriefcaseIcon className="w-4 h-4" />
          <span>{mission.type}</span>
        </div>
        <div className="flex items-center gap-2">
          <BuildingIcon className="w-4 h-4" />
          <span>{mission.company.email}</span>
        </div>
        <div className="flex items-center gap-2">
          <CalendarIcon className="w-4 h-4" />
          <span>Publié le {formatDate(mission.createdAt)}</span>
        </div>
      </div>
    </div>
  );
}