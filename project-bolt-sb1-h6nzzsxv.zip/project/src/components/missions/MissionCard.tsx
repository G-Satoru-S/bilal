import { Link } from 'react-router-dom';
import { CalendarIcon, BriefcaseIcon } from 'lucide-react';
import { Mission } from '../../types';
import { formatDate } from '../../lib/date';

interface MissionCardProps {
  mission: Mission;
}

export function MissionCard({ mission }: MissionCardProps) {
  return (
    <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100 hover:shadow-md transition">
      <Link to={`/mission/${mission.id}`}>
        <h2 className="text-xl font-semibold mb-2 text-gray-900">{mission.title}</h2>
      </Link>
      <p className="text-gray-600 mb-4 line-clamp-2">{mission.description}</p>
      
      <div className="flex items-center gap-4 text-sm text-gray-500">
        <div className="flex items-center gap-1">
          <BriefcaseIcon className="w-4 h-4" />
          <span>{mission.type}</span>
        </div>
        <div className="flex items-center gap-1">
          <CalendarIcon className="w-4 h-4" />
          <span>{formatDate(mission.createdAt)}</span>
        </div>
      </div>
      
      <div className="mt-4 flex items-center justify-between">
        <div className="text-sm text-gray-500">
          Par {mission.company.email}
        </div>
        <Link
          to={`/mission/${mission.id}`}
          className="text-blue-600 hover:text-blue-700 text-sm font-medium"
        >
          Voir les détails →
        </Link>
      </div>
    </div>
  );
}