import { useAuth } from '../../hooks/useAuth';
import { Mission } from '../../types';
import { Button } from '../ui/Button';

interface MissionActionsProps {
  mission: Mission;
}

export function MissionActions({ mission }: MissionActionsProps) {
  const { user } = useAuth();
  
  const isFreelance = user?.role === 'freelance';
  const isOwner = user?.id === mission.company.id;

  if (!user || (!isFreelance && !isOwner)) {
    return null;
  }

  return (
    <div className="bg-white p-8 rounded-lg shadow-sm border border-gray-100">
      {isFreelance && (
        <Button className="w-full">
          Postuler à cette mission
        </Button>
      )}
      
      {isOwner && (
        <div className="space-x-4">
          <Button variant="outline">Modifier</Button>
          <Button variant="outline">Supprimer</Button>
        </div>
      )}
    </div>
  );
}