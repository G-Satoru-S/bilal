import { Link } from 'react-router-dom';
import { BriefcaseIcon, UserCircleIcon } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { Button } from './ui/Button';

export function Navbar() {
  const { user, isAuthenticated, logout } = useAuth();

  return (
    <nav className="bg-white border-b border-gray-200">
      <div className="max-w-6xl mx-auto px-4">
        <div className="flex justify-between h-16">
          <div className="flex">
            <Link to="/" className="flex items-center">
              <BriefcaseIcon className="h-8 w-8 text-blue-600" />
              <span className="ml-2 text-xl font-bold">FreelanceHub</span>
            </Link>
            <div className="hidden sm:ml-6 sm:flex sm:space-x-4 items-center">
              <Link to="/missions" className="text-gray-700 hover:text-gray-900 px-3 py-2">
                Missions
              </Link>
              <Link to="/users" className="text-gray-700 hover:text-gray-900 px-3 py-2">
                Freelances
              </Link>
            </div>
          </div>

          <div className="flex items-center">
            {isAuthenticated ? (
              <div className="flex items-center space-x-4">
                <span className="text-gray-700">{user?.email}</span>
                <UserCircleIcon className="h-8 w-8 text-gray-400" />
                <Button variant="outline" onClick={logout}>
                  Déconnexion
                </Button>
              </div>
            ) : (
              <div className="space-x-4">
                <Link to="/login">
                  <Button variant="outline">Connexion</Button>
                </Link>
                <Link to="/register">
                  <Button>Inscription</Button>
                </Link>
              </div>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}