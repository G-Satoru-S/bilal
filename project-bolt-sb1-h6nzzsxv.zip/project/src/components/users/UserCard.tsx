import { UserCircleIcon, CalendarIcon } from 'lucide-react';
import { User } from '../../types';
import { formatDate } from '../../lib/date';

interface UserCardProps {
  user: User;
}

export function UserCard({ user }: UserCardProps) {
  return (
    <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100 hover:shadow-md transition">
      <div className="flex items-start gap-4">
        <div className="flex-shrink-0">
          <UserCircleIcon className="w-12 h-12 text-gray-400" />
        </div>
        
        <div className="flex-grow">
          <h2 className="text-xl font-semibold text-gray-900">{user.email}</h2>
          <div className="flex items-center gap-4 mt-2 text-sm text-gray-500">
            <div className="flex items-center gap-1">
              <CalendarIcon className="w-4 h-4" />
              <span>Membre depuis {formatDate(user.createdAt)}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}