import { useState } from 'react';
import { Button } from '../ui/Button';

export function UserFilters() {
  const [filters, setFilters] = useState({
    role: '',
  });

  return (
    <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100">
      <h2 className="font-semibold mb-4">Filtres</h2>
      
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Type de profil
          </label>
          <select
            value={filters.role}
            onChange={(e) => setFilters(prev => ({ ...prev, role: e.target.value }))}
            className="w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm"
          >
            <option value="">Tous</option>
            <option value="freelance">Freelance</option>
            <option value="entreprise">Entreprise</option>
          </select>
        </div>

        <Button
          variant="outline"
          className="w-full"
          onClick={() => setFilters({ role: '' })}
        >
          Réinitialiser les filtres
        </Button>
      </div>
    </div>
  );
}